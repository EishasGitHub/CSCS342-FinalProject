import React from 'react';
import { BrowserRouter as Router , Link } from 'react-router-dom';
import './App.css'; 
import HomeStack from './HomeStack';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Navbar2 from './components/Navbar2';
import { useState } from 'react';

const App = () => {
    const [status, setStatus] = useState(false);
    console.log(status)

    return (
        <Router>
            <div className='Main'>
                <header>
                   <Navbar /> 
                </header>

                <main>
                    <HomeStack/>
                </main>

                <footer>
                    <Footer/>
                </footer>
            </div>
        </Router>
    );
}

export default App;

