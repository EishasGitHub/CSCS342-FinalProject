import React from "react";
import {Route , Routes} from 'react-router-dom';

import Home from "./components/Home";
import Recipe from "./components/Recipe";
import Login from "./components/Login";
import SignUp from "./components/SignUp";
import Form from "./components/recipe_realm_form";

export default function HomeStack() {
    return (
        <Routes>
            <Route path="/" element={<Login/>} />
            <Route path="/Recipe" element={<Recipe/>} />
            <Route path="/Home" element={<Home/>} />
            <Route path="/SignUp" element={<SignUp/>} />
            <Route path="/Form" element={<Form/>}/>
        </Routes>
    );
}