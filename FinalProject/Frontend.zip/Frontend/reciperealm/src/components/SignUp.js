import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

export default function SignUp() {

    // const [pw, setPw] = useState('')
    // const [cpw, setCPw] = useState()

    const navigate = useNavigate();

    const [formData, setFormData] = useState({
        id: 'idk',
        username: '',
        email: '',
        password: '',
        registrationDate: 'idk',
    })

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const formDataToSend = new FormData();
        for (const key in formData) {
            formDataToSend.append(key, formData[key]);
        }
        try {
            const response = await axios.post('http://127.0.0.1:8000/api/allusers/', formDataToSend, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            });
            console.log(response.data);
            navigate('/Login');


        } catch (error) {
            console.error('There was an error!', error);
        }
    };

    return (
        <div className='formContainer'>
            <form className='formBox' >
                <h3 className='formHeading' >Sign Up</h3>
                <input type='email' placeholder='Enter your email' name='email' value={formData.email} onChange={handleChange} />
                <input type='text' placeholder='Enter username' name='username' value={formData.username} onChange={handleChange} />
                <input type='password' placeholder='Enter a strong password' name='password' value={formData.password} onChange={handleChange} />
                {/* <input type='password' placeholder='Confirm password' name='cpassword' value={cpw} onChange={(e) => { setCPw(e.target.value) }} /> */}
                <button type='submit' className='submitButton' onClick={handleSubmit}> Submit </button>
            </form>
        </div>
    );
}