import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

export default function Home() {
    const navigate = useNavigate();

    const GoToRecipe = () => {
        navigate('/Recipe')
    };

    const [recipes, setRecipes] = useState([])
    const [error, setError] = useState(null)

    useEffect(() => {
        axios.get(`http://127.0.0.1:8001/api/allrecipes/`)
            .then(response => {
                setRecipes(response.data);
            })
            .catch(error => {
                setError(error);
            });

    }, [])

    return (
        <div className="LatestRecipe">
            <p className="ListName">Latest Recipes</p>
            <div className="Container" onClick={GoToRecipe}>
                {recipes.map((item, index) => (
                    <div key={index}>
                        <div className="Description">{item.title}<br />by {item.author}</div>
                        <div className="ImageContainer">
                            <img className="foodImage" src={item.picture} alt="Food" />
                        </div>

                    </div>
                ))}
            </div>

        </div>
    );
}
