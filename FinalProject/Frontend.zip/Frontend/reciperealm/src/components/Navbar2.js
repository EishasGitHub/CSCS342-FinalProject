import React from 'react';

const Navbar2 = () => {

    return (
        <div className="Navbar">

            <div className='rightNav'>
                <img className='logo' src='logo.png' alt='logo'/>
                <h3 className='WebsiteTitle'>Recipe Realm</h3>
            </div>
        </div>
    );
}

export default Navbar2;