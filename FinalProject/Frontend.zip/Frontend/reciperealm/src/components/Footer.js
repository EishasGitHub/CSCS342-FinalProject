import React from "react";

export default function Footer() {
    return (
        <div className="Footer">
            <h3 className="footerHeading">Contact Us</h3>
            <div className="footerDetail">
                <div className="leftFoot">

                    <div className="IFE">
                        <img className="Icon" src="instagram.png" alt="instagram"/>
                        <p>@reciperealm_official</p>
                    </div>

                    <div className="IFE">
                        <img className="Icon" src="facebook.png" alt="facebook"/>
                        <p>@reciperealm_official</p>
                    </div>

                    <div className="IFE">
                        <img className="Icon" src="email.png" alt="email"/>
                        <p>reciperealm@gmail.com</p>
                    </div>
                    
                </div>

                <div className="MiddleFoot">
                    <img className="chefImage" src="logo.png" alt="chef"/>
                </div>

                <div className="rightFoot">
                    <div className="IFE">
                        <img className="Icon" src="contact.png" alt="contact"/>
                        <p>090078601</p>
                    </div>

                    <div className="IFE">
                        <img className="Icon" src="location.png" alt="location"/>
                        <p>Realm Recipe Land Private Limited</p>
                    </div>
                </div>

            </div>
            <p className="copyright">&copy; All Rights Reserved for Recipe Sharing Website</p>
        </div>
    );
}