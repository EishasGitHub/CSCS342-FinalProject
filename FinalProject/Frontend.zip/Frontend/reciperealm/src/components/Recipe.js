import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

export default function Recipe() {

    const [recipe, setRecipe] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const recipeId = 1; 

    useEffect(() => {
        axios.get(`http://127.0.0.1:8001/api/recipe/11`)
            .then(response => {
                setRecipe(response.data);
                setLoading(false);
            })
            .catch(error => {
                setError(error);
                setLoading(false);
            });
    }, [recipeId]);

    if (loading) return <div>Loading...</div>;
    if (error) return <div>Error: {error.message}</div>;

    return (
        <div className='content'>

            <div className='RecipeContainer'>
                <div className='sides'>
                    <div className='leftside'>
                        <h1 className='recipeName'>{recipe.title} by {recipe.author}</h1>

                        <h2 className='prepHeading'>Ingredients:</h2>
                        <p>{recipe.ingredients}</p>
                        <br />

                        <h2 className='prepHeading'>Instructions:</h2>
                        <p>{recipe.instructions}</p>
                        <br />

                        <h2 className='prepHeading'>Tips:</h2>
                        <p>{recipe.tips}</p>
                        <br />

                        <h2 className='prepHeading'>Enjoy making your {recipe.title}!</h2>
                    </div>

                    <div className='sideShow'>
                        <img className='displayImage' src={recipe.picture} alt='food image' />
                    </div>
                </div>
            </div>

        </div>
    );
}