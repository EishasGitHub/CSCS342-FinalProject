// import React, { useState } from 'react';
// import axios from 'axios';

// export default function Form() {

//   const [formData, setFormData] = useState({
//     id: 'idk',
//     title: '',
//     tips: '',
//     ingredients: '',
//     picture: '',
//     instructions: '',
//     author: '',
//     added_at: 'data'
//   });

//   // const handleChange = (e) => {
//   //   const { name, value } = e.target;
//   //   setFormData({
//   //     ...formData,
//   //     [name]: value
//   //   });
//   // };

//   const handleChange = (e) => {
//     const { name, value } = e.target;
//     setFormData((prevFormData) => ({
//       ...prevFormData,
//       [name]: value
//     }));
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     try {
//       const response = await axios.post('http://127.0.0.1:8000/api/allrecipes/', formData, {
//         headers: {
//           'Content-Type': 'application/json'
//         }
//       });
//       console.log(response.data);
//     } catch (error) {
//       console.error('There was an error!', error);
//     }
//   };

//   return (
//     <div className="main-block">
//       <form>
//         <h1>Create Recipe</h1>
//         <div className='info'>

//           <label>Title</label>
//           <input type='text' name='title' value={formData.name} onChange={handleChange} />

//           <label>Ingredients</label>
//           <textarea rows="4" name='ingredients' value={formData.ingredients} onChange={handleChange}></textarea>

//           <label>Instructions</label>
//           <textarea rows="4" name='instructions' value={formData.instructions} onChange={handleChange}></textarea>

//           <label>Tips</label>
//           <textarea rows="4" name='tips' value={formData.tips} onChange={handleChange}></textarea>

//           <label>Recipe Image (add a link)</label>
//           <input type="url" name='picture' value={formData.picture} onChange={handleChange} />

//         </div>

//         {/* <button type="submit" href="/" onClick={handleSubmit}>Submit</button> */}

//         <input type='submit' onClick={handleSubmit} />

//       </form>
//     </div>
//   );
// }


import React, { useState } from 'react';
import axios from 'axios';

export default function Form() {

  const [formData, setFormData] = useState({
    id: 'idk',
    title: '',
    tips: '',
    ingredients: '',
    picture: '',
    instructions: '',
    author: '',
    added_at: 'data'
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formDataToSend = new FormData();
    for (const key in formData) {
      formDataToSend.append(key, formData[key]);
    }
    try {
      const response = await axios.post('http://127.0.0.1:8001/api/allrecipes/', formDataToSend, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      });
      console.log(response.data);
    } catch (error) {
      console.error('There was an error!', error);
    }
  };

  return (
    <div className="main-block">
      <form onSubmit={handleSubmit}>
        <h1>Create Recipe</h1>
        <div className="info">
          <label>Recipe Name</label>
          <input type="text" name="title" value={formData.title} onChange={handleChange} />

          <label>Ingredients</label>
          <textarea rows="4" name="ingredients" value={formData.ingredients} onChange={handleChange}></textarea>

          <label>Instructions</label>
          <textarea rows="4" name="instructions" value={formData.instructions} onChange={handleChange}></textarea>

          {/* <label>Author</label>
          <textarea rows="4" name="author" value={formData.author} onChange={handleChange}></textarea> */}

          <label>Tips</label>
          <textarea rows="4" name="tips" value={formData.tips} onChange={handleChange}></textarea>

          <label>Recipe Image (add a link)</label>
          <input type="url" name='picture' value={formData.picture} onChange={handleChange} />

        </div>
        <button type="submit">Submit</button>
      </form>
    </div>
  );
}
