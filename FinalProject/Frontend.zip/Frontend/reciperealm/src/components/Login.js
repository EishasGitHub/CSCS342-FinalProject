import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

export default function Login({setStatus}) {

    const [formData, setFormData] = useState({ username: '', password: '' });
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');
    const [users, setUsers] = useState('');
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const navigate = useNavigate();     

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    useEffect(() => {
        axios.get(`http://127.0.0.1:8000/api/allusers/`)
            .then(response => {
                setUsers(response.data);
            })
            .catch(error => {
                setError(error);
            });

    }, [])

    const handleSubmit = (e) => {
        e.preventDefault();
        setError('');
        setSuccess('');
        try {
            const user = users.find(user => user.username === formData.username && user.password === formData.password);

            if (user) {
                setSuccess('Login successful!');
                console.log(success)
                setIsLoggedIn(true);
                // setStatus(true);
                navigate('/Home');

            } else {
                setError('Invalid username or password');
                console.log(error)
                alert(error);
            }
        }

        catch (error) {
            setError('There was an error contacting the server');
        }
    };

    const gotoSignUp = () => {
        navigate('/SignUp')
    };

    return (
        <div className='formContainer' >
                
            <form className='formBox' >
                <h3 className='formHeading'>Login</h3>

                <input type='text' placeholder='Enter your username' name='username' value={formData.username} onChange={handleChange} />

                <input type='password' placeholder='Enter your password' name='password' value={formData.password} onChange={handleChange} />

                <button type='submit' className='submitButton' onClick={handleSubmit}>Submit</button>
                
                <button className='SignUp' onClick={gotoSignUp}>Sign Up</button>
            </form>
        </div>
    );
}