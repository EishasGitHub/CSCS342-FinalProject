import React from 'react';
import { useNavigate } from 'react-router-dom';

const Navbar = () => {
    const navigate = useNavigate();

    const goHome = () => {
        navigate('/Home')
    };

    const handleLogout = () => {
        navigate('/')
    };

    const handleCreateRecipe = () => {
        navigate('/Form')
    };

    return (
        <div className="Navbar">

            <div className='rightNav' onClick={goHome}>
                <img className='logo' src='logo.png' alt='logo'/>
                <h3 className='WebsiteTitle'>Recipe Realm</h3>
            </div>

            <div className='leftNav'>
                <h3 className='navHome' onClick={goHome}>Home</h3>
                <h3 className='navCreateRecipe' onClick={handleCreateRecipe}>Create Recipe</h3>
                <h3 className='navLogout' onClick={handleLogout}>Logout</h3>
            </div>
        </div>
    );
}

export default Navbar;
