from django.contrib import admin
from firstapp.models import Recipe

# Register your models here.

admin.site.register(Recipe)