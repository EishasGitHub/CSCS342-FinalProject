from rest_framework import serializers
from .models import Recipe

class RecipeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Recipe
        fields = ('id', 'title', 'tips', 'ingredients', 'picture', 'instructions', 'author', 'added_at')
